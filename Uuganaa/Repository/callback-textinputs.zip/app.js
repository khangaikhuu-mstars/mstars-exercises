const nameInput = document.getElementById('name');
const messageTextArea = document.getElementById('message');

